<div class="navbar-collapse collapse">
 <!--NAVIGATIONSELEMENTE-->
    <ul class="nav navbar-nav">
    <li><a href="#">Test1</a></li>
    <li><a href="#">Test2</a></li>
    <li><a href="#"></a></li>


    <li class="dropdown hidden-xs hidden-sm">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown-Men� <span class="caret"></span></a>
      <ul class="dropdown-menu" role="menu">
        <li><a href="#">Aktion</a></li>
        <li><a href="#">Andere Aktion</a></li>
        <li><a href="#">Irgendwas anderes</a></li>
        <li class="divider"></li>
        <li class="dropdown-header">Nav-�berschrift</li>
        <li><a href="#">Abgetrennter Link</a></li>
        <li><a href="#">Noch ein abgetrennter Link</a></li>
      </ul>
    </li>
  </ul>
 <!--NAVIGATIONSELEMENTE-->
</div>