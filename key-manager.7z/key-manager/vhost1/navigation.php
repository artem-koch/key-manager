<!--Header-->
<meta charset="utf-8">
    <div class="row no-border">
      <div class="col-sm-12 no-border">
        <img src="img/header.jpg" class="img-responsive" alt="Ein Bild vom Schulhof">
        <div class="headtext">
        
        <!--NAVIGATION-->
            <div class="navbar navbar-default" role="navigation">
                <div class="navbar-header ">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Navigation ein-/ausblenden</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
        
                </div>
                <div class="navbar-collapse collapse">
                 <!--NAVIGATIONSELEMENTE-->
                    <ul class="nav navbar-nav">      
                    <li><a href="index.php">Übersicht</a></li>
                    <li><a href="key.php">Schlüssel</a></li>
                    <li><a href="person.php">Personen</a></li>
        			      <li><a href="gms.php">Räume</a></li>
        		<!--	<li><a href="wrs.php">bla</a></li>
        			<li><a href="termine.php">bla</a></li>
        			<li><a href="preset.php">bla</a></li> -->
                  </ul>
                 <!--NAVIGATIONSELEMENTE--> 
                </div>
            </div>
        <!--/NAVIGATION-->
          <p id="position">Home &#8594; Unsere Schule</p>
        </div>
      </div>
    </div>
<!--/Header-->
